<h1>Ejercicio 1: PHP Basics</h1>
<p>Escribe un programa en PHP que tome un número entero como entrada y determine si es un número primo. El programa debe imprimir "Es primo" si el número es primo, y "No es primo" si no lo es.</p>
<br>
<p>Nota: el numero debe de ingresarse por url.<br>ejemplo:<br><br> http://localhost/ejercicio01/?number=555</p> 
<hr>