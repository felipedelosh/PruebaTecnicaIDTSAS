<h1>Ejercicio 2: JavaScript Basics</h1>
<p>Escribe una función en JavaScript que reciba un arreglo de números como entrada y devuelva la suma de los números pares en el arreglo.</p>
<br>
<p>Nota: ingrese los numeros separados por ","</p>
<br>
<input type="text" id="arrayNumbers" name="arrayNumbers" required minlength="10" maxlength="200" size="50">
<button onclick="sumVector()">SUMAR!!!</button> 
<hr>
<p id="result">?</p>

<script src="js/javascript.js"></script>