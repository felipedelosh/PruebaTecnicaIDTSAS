<h1>Ejercicio 4: JavaScript + DOM Manipulation</h1>
<p>Crea una página HTML con un botón. Escribe una función en JavaScript que, al hacer clic en el botón, cambie el color de fondo de la página al azar</p>
<hr>
<button onclick="changeColorBG()">COLOR!!!</button>
<script src="js/javascript.js"></script>