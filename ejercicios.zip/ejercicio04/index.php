<?php
include("includes/header.php");
include("includes/banner.php");
include("includes/footer.php");
?>