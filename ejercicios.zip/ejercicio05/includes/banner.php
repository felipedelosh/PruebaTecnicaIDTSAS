<h1>Ejercicio 5: PHP + MySQL</h1>
<p>Escribe una consulta en PHP para seleccionar todos los usuarios de la tabla "usuarios" cuyo nombre comienza con la letra "A" y ordenarlos alfabéticamente de forma ascendente. Imprime los resultados en forma de una lista ordenada.</p>
<hr>