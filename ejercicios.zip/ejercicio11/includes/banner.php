<h1>Ejercicio 1: PHP Object-Oriented Programming (OOP)</h1>
<p>Crea una clase en PHP llamada "Empleado" con los siguientes atributos: nombre, salario y puesto. Implementa un método llamado obtenerSalarioAnual() que devuelva el salario anual del empleado (asumiendo que el salario mensual se proporciona).</p>
<hr>