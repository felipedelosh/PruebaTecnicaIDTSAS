<h1>Ejercicio 2: JavaScript Advanced Concepts</h1>
<p>Escribe una función en JavaScript que reciba una cadena de texto como entrada y devuelva la misma cadena, pero con las palabras en orden inverso. Por ejemplo, si la entrada es "Hola, cómo estás", la función debería devolver "estás cómo Hola,".</p>
<hr>
<h3 id="output">?</h3>
<script src="js/javascript.js"></script>