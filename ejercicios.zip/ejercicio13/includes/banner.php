<h1>Ejercicio 3: PHP + MySQL Advanced</h1>
<p>Supongamos que tienes dos tablas en una base de datos MySQL: "productos" y "ventas". La tabla "productos" tiene los campos id, nombre y precio. La tabla "ventas" tiene los campos id, producto_id, cantidad y fecha. Escribe una consulta en PHP que devuelva el nombre del producto más vendido y la cantidad total de ventas para ese producto.</p>
<p>Nota: ejecutar el script.sql</p>
<hr>