<form action="login.php" method="POST">
  <input type="password" name="password" autofocus>
  <input type="submit" name="save_empleado" value="VALIDATE">
</form> 