<?php
define ("urlsite", "http://localhost/ejercicio21");
?>