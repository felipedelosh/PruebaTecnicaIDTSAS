<h2>Ingrese usuario para eliminar:</h2>
<form action="" method="GET">
  <input type="text" name="idUser" placeholder="ID" autofocus>
  <br>
  <input type="submit" name="deleteUser" value="DELETE">
  <br>
  <input type="hidden" name="option" value="deleteUser">
</form> 