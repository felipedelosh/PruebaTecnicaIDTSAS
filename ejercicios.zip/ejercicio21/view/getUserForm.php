<h2>Ingrese ID deusuario para vista detallada:</h2>
<form action="" method="GET">
  <input type="text" name="idUser" placeholder="ID" autofocus>
  <br>
  <input type="submit" name="getUser" value="GET">
  <br>
  <input type="hidden" name="option" value="getUser">
</form> 