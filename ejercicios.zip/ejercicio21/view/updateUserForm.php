<h2>Ingrese datos usuario:</h2>
<form action="" method="GET">
  <input type="text" name="idUser" placeholder="ID USUARIO" autofocus>
  <br>
  <input type="text" name="nameUser" placeholder="NOMBRE USUARIO">
  <br>
  <input type="text" name="emailUser" placeholder="CORREO USUARIO">
  <br>
  <input type="password" name="passwordUser" placeholder="**********">
  <br>
  <input type="submit" name="saveUser" value="SAVE">
  <br>
  <input type="hidden" name="option" value="updateUser">
</form> 