<br>
<a href="index.php?option=all">Ver todos los Usuario</a>
<br>
<a href="index.php?option=get">Obtener información de usuario</a>
<br>
<a href="index.php?option=update">Actualizar información de usuario</a>
<br>
<a href="index.php?option=new">Crear Usuario</a>
<br>
<a href="index.php?option=delete">Borrar Usuario</a>
<hr>
<br>