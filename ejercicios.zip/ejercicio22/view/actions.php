<button id="viewAllTask">Ver todas las tareas</button>
<br>
<button id="viewTask">Ver tareas filtrada por ID</button>
<br>
<button id="addTask">Agregar tareas</button>
<br>
<button id="editTask">Editar tareas</button>
<br>
<button id="deleteTask">Eliminar tareas</button>
<script src="lib/jquery.js"></script>
<script type="module" src="js/javascript.js"></script>