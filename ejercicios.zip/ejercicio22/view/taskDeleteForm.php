<div id="deleteTaskForm">
  <h1>Eliminar tarea:</h1>
  <br>
  <input type="text" id="idTaskDelete" placeholder="Ingrese el identificador de la tarea">
  <br>
  <button type="button" id="btnDeleteTask">Borrar</button>
  <br><br><br>
</div>