<div id="taskEditForm">
  <h1>Editar tarea:</h1>
  <br>
  <input type="text" id="idTaskEdit" placeholder="Ingrese el identificador de la tarea">
  <br>    
  <input type="text" id="nameTaskEdit" placeholder="Ingrese el titulo de la tarea">
  <br>
  <input type="text" id="descriptionTaskEdit" placeholder="Ingrese la descripción de la tarea">
  <br>
  <input type="checkbox" id="isCompleteEdit" value="false">
  <label for="lblTaskIsCompleteEdit">Completada?</label><br>
  <button type="button" id="btnEditTask">Editar</button>
  <br><br><br>
</div>