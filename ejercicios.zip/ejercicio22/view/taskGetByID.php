<div id="taskGetByID">
<br>
<h1>Ingrese el ID a buscar: </h1>
<input type="text" id="idTask" placeholder="Inser task ID">
<button type="button" id="searchAndShowTaskByID">Buscar</button> 
<br><br><br>
</div>